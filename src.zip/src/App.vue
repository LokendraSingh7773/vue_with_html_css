<script setup>
import { RouterLink, RouterView } from 'vue-router'
import Main from './components/Main.vue'
</script>
<template>
  <main>
    <Main/>
  </main>
</template>


