<template>
      <section class="first_section">
        <div>
        <div class="paragraph">
          <div class="p-5" >
            <h2 class="pb-4 pt-5" >
                About Us
            </h2>
            <p>Amet luctus venenatis lectus magna fringilla urna porttitor rhoncus<br> dolor. 
               A lacus vestibulum sed arcu non. Dolor magna eget est lorem <br>ipsum dolor sit amet consectetur.
            </p>
            <button class="btn btn-primary mt-4 mb-5 rounded-0"><a>Read more</a> </button>
          </div>
        </div>
    </div>
      </section>

      <!-- Second Section  -->
      <section class="second_section">
        <div class="container pt-4 pb-4">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pb-4" id="second_section_fisrt_row">
                    <div>
                        <div class="second_section_fisrt_row_h1 mb-5">
                          <h1>About</h1>
                        </div>
                        <div class="second_section_fisrt_row_p  mb-4">
                            <p>Oh feel if up to till like. He an thing rapid these after going <br>drawn or. Timed she his law the spoil round defer. In <br> surprise concerns informed betrayed he learning is ye.<br> Ignorant formerly so ye blessing. 
                            </p>
                        </div>
                        <div class="second_section_fisrt_row_h6 mt-2">
                            <h6>He as spoke avoid given downs money on we. Of <br> properly carriage shutters ye as wandered up repeated <br> moreover.</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 py-3" id="second_section_row">
                    <div class="pb-4" id="second_section_div1">
                        <div class="second_section_row_image">
                            <img  src="src/assets/phone_call.png" style="width: 55px; height: 55px;"/>
                        </div>
                        <div class="second_section_row_h5_p mt-4">
                            <div class="second_section_row_h5 pt-2">
                                <h5>
                                    Research
                                </h5>
                            </div>
                            <div class="second_section_row_p">
                                <p>
                                   Duis aute irure dolor in reprehenderit in voluptate <br> velit esse cillum dolore eu fugiat nulla pariatur.<br>Excepteur sint occaecat cupidatat non proident,<br> sunt in culpa qui officia deserunt mollit anim id est<br> laborum.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="pb-4" id="second_section_div1">
                        <div class="second_section_row_image">
                            <img  src="src/assets/settings.png" style="width: 55px; height: 55px;"/>
                        </div>
                        <div class="second_section_row_h5_p mt-4">
                            <div class="second_section_row_h5 pt-2">
                                <h5>
                                    Strategy
                                </h5>
                            </div>
                            <div class="second_section_row_p">
                                <p>
                                   Duis aute irure dolor in reprehenderit in voluptate <br> velit esse cillum dolore eu fugiat nulla pariatur.<br>Excepteur sint occaecat cupidatat non proident,<br> sunt in culpa qui officia deserunt mollit anim id est<br> laborum.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="pb-4" id="second_section_div1">
                        <div class="second_section_row_image">
                            <img  src="src/assets/ringing.png" style="width: 55px; height: 55px;"/>
                        </div>
                        <div class="second_section_row_h5_p mt-4">
                            <div class="second_section_row_h5 pt-2">
                                <h5>                                    
                                    Design
                                </h5>
                            </div>
                            <div class="second_section_row_p">
                                <p>
                                   Duis aute irure dolor in reprehenderit in voluptate <br> velit esse cillum dolore eu fugiat nulla pariatur.<br>Excepteur sint occaecat cupidatat non proident,<br> sunt in culpa qui officia deserunt mollit anim id est<br> laborum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Third Section -->
    <section class="third_section pb-2">
        <div>
            <div class="container py-5 " id="third_section_container">
                <div class="row" id="third_section_row">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 " id="third_card_section">
                        <div class="card mt-4 rounded-0" id="third_section_card">
                            <div class="third_section_card_img mt-4">
                                <img  src="src/assets/phone_call.png" style="width:50px; height: 50px;"/>
                            </div>
                            <div class="third_section_card_h6">
                                <h6>
                                    Visualize it
                                </h6>
                            </div>
                            <div class="third_section_card_p">
                                <p>
                                    Sample text. Click to select the text box. Click again or double click to start editing the text.
                                </p>
                            </div>
                        </div>    
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="third_card_section">
                        <div class="card mt-4 rounded-0" id="third_section_card">
                            <div class="third_section_card_img mt-4">
                                <img  src="src/assets/phone_call.png" style="width:50px; height: 50px;"/>
                            </div>
                            <div class="third_section_card_h6">
                                <h6>
                                    Create it
                                </h6>
                            </div>
                            <div class="third_section_card_p">
                                <p>
                                    Sample text. Click to select the text box. Click again or double click to start editing the text.
                                </p>
                            </div>
                        </div>    
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="third_card_section">
                        <div class="card mt-4 rounded-0" id="third_section_card">
                            <div class="third_section_card_img mt-4">
                                <img  src="src/assets/phone_call.png" style="width:50px; height: 50px;"/>
                            </div>
                            <div class="third_section_card_h6">
                                <h6>
                                    Grow it
                                </h6>
                            </div>
                            <div class="third_section_card_p">
                                <p>
                                    Sample text. Click to select the text box. Click again or double click to start editing the text.
                                </p>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Fourth Section -->
    <section class="fourth_section pt-5 ">
        <div>
            <div class="container pt-5 " id="fourth_section_container">
                <div class="row" id="fourth_section_row" >
                    <div class="col-lg-6 col-md-6 com-sm-12 col-xs-12" id="fourth_section_col-lg_1">
                        <div>
                            <div class="fourth_section_h1">
                                <h1>What We Do</h1>
                            </div>
                            <div class="fourth_section_p pt-2">
                                <p>
                                    Article evident arrived express highest men did boy. Mistress<br> sensible entirely am so. Quick can manor smart money hopes worth<br> too. Comfort produce husband boy her had hearing. Law others<br> theirs passed but wishes. You day real less till dear read.
                                </p>
                            </div>
                            <div>
                                <button class="btn btn-primary rounded-0 px-4 py-2 mt-4">Read More</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 com-sm-12 col-xs-12" id="fourth_section_col-lg_2">
                        <div>
                            <div class="fourth_section_image">
                                <img class="img-fluid" src="src/assets/person.png" style="width: 600px; height:620px;"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Fifth Section -->
    <section class="fifth_section pt-5">
        <div class="container pt-3" id="fifth_section_container">
            <div class="row" id="fifth_section_row">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12" id="fifth_section_row_col-lg-1" >
                        <div>
                            <img class="img-fluid" src="src/assets/person2.png" style="width: 600px; height: 650px;"/>
                        </div>
                    </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 pt-5" id="fifth_section_row_col-lg-2" >
                    <div class="side_data_fifth_section">
                        <div class="fifth_section_h1">
                            <h1>Paul Hudson</h1>
                        </div>
                        <div class="fifth_section_h3 mt-4 pb-3">
                            <h3>SEO</h3>
                        </div>
                        <div class="fifth_section_p pb-5">
                            <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing. Law others theirs passed but wishes. You day real less till dear read.</p>
                        </div>
                    </div>
                    <div>
                        <div class="fifth_section_h1 ">
                            <h1>Linda Larson</h1>
                        </div>
                        <div class="fifth_section_h3 mt-4 pb-3">
                            <h3>Manager
                            </h3>
                        </div>
                        <div class="fifth_section_p">
                            <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing. Law others theirs passed but wishes. You day real less till dear read.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
</template>


<style scoped>

/* Sixth Section */
@media (max-width: 765px){
    .fourth_section{
        text-align: center;
    }
    #second_section_fisrt_row{ order: 2;}
    #second_section_row  { order: 1}
    #fifth_section_row_col-lg-2{
        padding-right: 0px !important;
    }
}


/* Fifth Section */
.fifth_section_h1 {
    background: #2590f4;
    color: white;
    padding: 6px;
}
.fifth_section_h1 h1 {
    margin-left: 2rem;
    padding: 7px;
    font-size: 27px;
}
div#fifth_section_row_col-lg-1 {
    padding-left: 2rem;
}
div#fifth_section_row_col-lg-2 {
    padding-right: 9rem;
}
.fifth_section_p p {
    font-size: large;
    font-weight: 400;
    color: #818181;
}
.fifth_section_h3 h3 {
    font-weight: 700;
    font-size: 23px;
}



/* Fourth Section */
.fourth_section{
    background-color: #f2f2f2;
}
div#fourth_section_col-lg_1 {
    display: flex;
    position: relative;
    justify-content: end;
    align-self: center;
}
.fourth_section_p.pt-2 {
    font-size: 19px;
}


/*  Third Section */
.third_section{
    background: url("https://images01.nicepagecdn.com/a1389d7bc73adea1e1c1fb7e/e6aafe75c27457318a5f4539/pexels-photo-3914752.jpg");
    background-position: 50% 50%;
    background-size: cover;
}
div#third_card_section {
    text-align: center;
}
div#third_section_card {
    border-bottom: 19px solid #2590f4;
    border-top: none;
    border-right: none;
    border-left: none;
    padding: 30px 0px 30px 0px;
    margin: 0px 0 0px 0;
}
.third_section_card_img {
    background: #2590f4;
    position: relative;
    width: fit-content;
    align-self: center;
    padding: 0.8rem;
    border-radius: 50%;
}
.third_section_card_h6 h6 {
    font-size: x-large;
    font-weight: 400;
    margin-top: 10px;
}
.third_section_card_p {
    color: #818181;
}
.third_section_card_p {
    margin-top: 8px;
    margin-bottom: 8px;
    padding: 0 24px;
    font-size: 18px;
    line-height: 1.9rem;
}
div#third_section_row {
    padding: 0 15px;
}







/* Second Section */
.second_section_row_image {
    background:#2590f4;
    color: white;
    display: inline-flex;
    position: absolute;
    padding: 25px;
    margin-top:9px;
    border-radius: 50%;
}
.second_section_row_h5_p {
    margin-left: 9rem;
}
.second_section_row_h5 h5 {
    font-size: larger;
    font-weight: 400 !important;
}
.second_section_row_p p {
    font-size: medium;
    margin-top: 17px;
}
div#second_section_fisrt_row {
    display: flex;
    position: relative;
    justify-content: space-around;
    align-items: center;
}
.second_section_fisrt_row_p p {
    line-height: 2rem;
    font-family: inherit;
    font-size: large;
    font-weight: 400;
    color: #1d1d1d;
}
.second_section_fisrt_row_h6 h6 {
    line-height: 1.6rem;
    font-weight: 700;
}

body{
  font-family: "Roboto", "Arial","sans-serif";
}


/* First Section */
.first_section{
  background-image: linear-gradient(0deg, rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url("src/assets/about_background.jpeg");
  background-position: 50% 50%;
  background-size: contain;
  min-height: 670px;
  background-size: cover;
  display: flex-root;
  text-align: -webkit-center;
}
.paragraph {
  width: fit-content;
  text-align: center;
  display: flex;
}
.paragraph div{
  border:15px solid #2590f4;
  padding: 40px 60px 40px 60px;
  margin-top: 80px;
  background-color: #f6f6f63d;
  
}
.paragraph h2{
  font-weight: 700;
  font-family: sans-serif !important;
  font-size: 3.3rem;
  color: white;
  line-height: 3.9rem;
}
.paragraph p{
  color: white;
  font-family: Montserrat, sans-serif !important;
  font-size: 1.150rem;
  margin-top: 5px;
}
button a{  
    color: white;
    padding: 8px 15px 8px 15px;
}
button.btn.btn-primary.mt-4.mb-5.rounded-0 {
    padding: 10px;
}
</style>

