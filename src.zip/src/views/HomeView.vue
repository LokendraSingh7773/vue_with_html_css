<template>
      <section class="first_section">
        <div class="paragraph">
          <div>
            <h2 clas>
              We Are Increasing <br>Business Success <br> With IT Solution
            </h2>
            <p class="mt-3">Amet luctus venenatis lectus magna fringilla urna porttitor rhoncus <br> dolor. 
               A lacus vestibulum sed arcu non. Dolor magna eget est lorem <br> ipsum dolor sit amet consectetur.
            </p>
            <button class="btn btn-primary mt-4"><a>Read more</a> </button>
          </div>
        </div>
      </section>

      <!-- Second Section -->
      <section class="hello">
        <div>
          <div>
            <div class="hello_header">
              <h2>We advise leaders on strategy, <br>marketing, organization and IT</h2>
            </div>
            <div class="container">
              <div id="row_wise" class="row mb-5">
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="slide1">
                    <div>
                        <img id="right_click" src="src/assets/right.png"/>
                    </div>
                    <div>
                      <p>
                          <strong>Sample text.</strong> Click to select the text box. <br>Click again or double click to start editing <br>the text. Duis aute irure dolor in<br> reprehenderit in voluptate velit esse<br> cillum dolore eu fugiat nulla pariatur.
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="slide1" >
                    <div>
                        <img id="right_click" src="src/assets/right.png"/>
                    </div>
                    <div>
                      <p>
                          <strong>Sample text.</strong> Click to select the text box. <br>Click again or double click to start editing <br>the text. Duis aute irure dolor in<br> reprehenderit in voluptate velit esse<br> cillum dolore eu fugiat nulla pariatur.
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="slide1">
                    <div>
                        <img id="right_click" src="src/assets/right.png"/>
                    </div>
                    <div>
                      <p>
                          <strong>Sample text.</strong> Click to select the text box. <br>Click again or double click to start editing <br>the text. Duis aute irure dolor in<br> reprehenderit in voluptate velit esse<br> cillum dolore eu fugiat nulla pariatur.
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="slide1">
                    <div>
                        <img id="right_click" src="src/assets/right.png"/>
                    </div>
                    <div>
                      <p>
                          <strong>Sample text.</strong> Click to select the text box. <br>Click again or double click to start editing <br>the text. Duis aute irure dolor in<br> reprehenderit in voluptate velit esse<br> cillum dolore eu fugiat nulla pariatur.
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="slide1">
                    <div>
                        <img id="right_click" src="src/assets/right.png"/>
                    </div>
                    <div>
                      <p>
                          <strong>Sample text.</strong> Click to select the text box. <br>Click again or double click to start editing <br>the text. Duis aute irure dolor in<br> reprehenderit in voluptate velit esse<br> cillum dolore eu fugiat nulla pariatur.
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12" id="slide1">
                    <div>
                        <img id="right_click" src="src/assets/right.png"/>
                    </div>
                    <div>
                      <p>
                          <strong>Sample text.</strong> Click to select the text box. <br>Click again or double click to start editing <br>the text. Duis aute irure dolor in<br> reprehenderit in voluptate velit esse<br> cillum dolore eu fugiat nulla pariatur.
                      </p>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </section> 

      <!-- Third Section -->
      <section class="images_section">
        <div>
            <div class="container mt-5">
              <div id="row_wise" class="row pt-4 ">
              <div id="hello_3" class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mt-3 mb-1">
                     <img class="img-fluid" id="for_cover" src="src/assets/pexels-phot.jpeg"  style="width: 353px; height: 352px;"/>
              </div>
              <div id="hello_3" class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mt-3 mb-1">
                     <img class="img-fluid" id="for_cover" src="src/assets/pexels-phot3.jpeg"  style="width: 353px; height: 352px;"/>
              </div>
              <div id="hello_3" class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mt-3 mb-1">
                     <img class="img-fluid" id="for_cover" src="src/assets/pexels-phot2.jpeg"  style="width: 353px; height: 352px;"/>
              </div>
              <div id="hello_3" class="col-lg-4 col-md-6 col-sm-12col-xs-12 mt-3 mb-1">
                     <img class="img-fluid" id="for_cover" src="src/assets/pexels-phot4.jpeg"  style="width: 353px; height: 352px;"/>
              </div>
              <div id="hello_3" class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mt-3 mb-1">
                     <img class="img-fluid" id="for_cover" src="src/assets/pexels-phot5.jpeg"  style="width: 353px; height: 352px;"/>
              </div>
              <div id="hello_3" class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mt-3 mb-1">
                     <img class="img-fluid" id="for_cover" src="src/assets/pexels-phot6.jpeg"  style="width: 353px; height: 352px;"/>
              </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 d-grid gap-2  mx-auto justify-content-center pt-4 pb-2">
                <button class="btn btn-primary mb-5 px-5 py-2" >View More</button></div>
            </div>
        </div>
      </section>

       <!-- Fourth Section -->
      <section>
        <div>
          <div class="container mt-5">
            <div id="row_wise" class="row mt-5 mx-4">
              <div id="profiles" class="col-lg-4 mt-4 mb-5">
                <div>
                     <img src="src/assets/2.jpg"  style="width: 280px; height: 280px;"/>
                  </div>
                  <div><h5 class="mt-4">Mary Brown</h5></div>
                  <div class="mb-3 mt-2"> <h6>creative leader</h6></div>
                  <div class="para mt-1"> <a>Glavi amet ritnisl libero molestie ante ut <br>fringilla purus eros quis glavrid from <br>dolor amet iquam lorem bibendum </a></div>
                    <div class="icons mt-4 px-xxl-5  py-2 text-white">
                      <div  class=" social_media_icon">
                        <i class="bi bi-twitter"></i>
                        <i class="bi bi-instagram"></i>
                        <i class="bi bi-facebook"></i>
                      </div>
                  </div>
              </div>
              <div id="profiles" class="col-lg-4 mt-4 mb-5">
                <div>
                     <img src="src/assets/3.jpg"  style="width: 280px; height: 280px;"/>
                  </div>
                  <div><h5 class="mt-4">Bob Greenfield</h5></div>
                  <div class="mb-3 mt-2"> <h6>programming guru</h6></div>
                  <div class="para mt-1"> <a>Glavi amet ritnisl libero molestie ante ut <br>fringilla purus eros quis glavrid from <br>dolor amet iquam lorem bibendum </a></div>
                    <div class="icons mt-4 px-xxl-5  py-2 text-white">
                      <div  class=" social_media_icon">
                        <i class="bi bi-twitter"></i>
                        <i class="bi bi-instagram"></i>
                        <i class="bi bi-facebook"></i>
                      </div>
                  </div>
              </div>
              <div id="profiles" class="col-lg-4 mt-4 mb-5">
                <div>
                     <img src="src/assets/4.jpg"  style="width: 280px; height: 280px;"/>
                  </div>
                  <div><h5 class="mt-4">Ann Richmond</h5></div>
                  <div class="mb-3 mt-2"> <h6>sales manager</h6></div>
                  <div class="para mt-1"> <a>Glavi amet ritnisl libero molestie ante ut <br>fringilla purus eros quis glavrid from <br>dolor amet iquam lorem bibendum </a></div>
                    <div class="icons mt-4 px-xxl-5  py-2 text-white">
                      <div  class=" social_media_icon">
                        <i class="bi bi-twitter"></i>
                        <i class="bi bi-instagram"></i>
                        <i class="bi bi-facebook"></i>
                      </div>
                  </div>
              </div>
            </div>           
          </div>
        </div>
      </section>


      <!-- Fifth Section -->
      <section class="section_5 pb-3">
        <div class="container ">
          <div  class=" row pt-5  pb-4 pb-4">
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 card pt-4 border-0 mx-3 mb-4 pb-4">
              <div class="section_increment" >
                <span class="dot mt-4 pt-3 pl-4">35m+</span>
              </div>   
              <div class="mt-3">
                <h5>Square feet managed</h5>
              </div>
              <div class="section_increment_p mt-2 mb-2">
                <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing.</p>
              </div>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 card pt-4 border-0 mx-3 mb-4 pb-4">
              <div class="section_increment" >
                <span class="dot mt-4 pt-3 pl-4">158</span>
              </div>   
              <div class="mt-3">
                <h5>Employees on our team</h5>
              </div>
              <div class="section_increment_p mt-2 mb-2">
                <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing.</p>
              </div>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 card pt-4 border-0 mx-3 mb-4 pb-4" >
              <div class="section_increment" >
                <span class="dot mt-4 pt-3 pl-4">250+</span>
              </div>   
              <div class="mt-3">
                <h5>Happy Clients</h5>
              </div>
              <div class="section_increment_p mt-2 mb-2">
                <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing.</p>
              </div>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 card pt-4 border-0 mx-3 mb-4 pb-4">
              <div class="section_increment " >
                <span class="dot mt-4 pt-3 pl-4">34</span>
              </div>   
              <div class="mt-3">
                <h5>Awards</h5>
              </div>
              <div class="section_increment_p mt-2 mb-2">
                <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing.</p>
              </div>
            </div>
          </div>
        </div>
      </section>


    <!-- Sixth Section -->
    <section class="sixth_section">
      <div class="container py-4" id="sixth_section_container">
        <div class="row  py-1" id="sixth_section_row">
          <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12" id="sixth_section_1stcol_lg">
            <div>
              <div class="sixth_section_1stcol_lg_h5">
                  <h5>Explore national parks with digital tours, ranger programs, educational opportunities, and more.</h5>
              </div>
              <div class="sixth_section_icon_img_div mt-4">
                <div>
                  <img class="mt-1" src="src/assets/right_click.png"  style="width: 16px; height: 16px;"/>
                  <p>Lorem ipsum dolor sit amet, consectetur</p>
                </div>
                <div>
                  <img class="mt-1" src="src/assets/right_click.png"  style="width: 16px; height: 16px;"/>
                  <p>Elit, sed do eiusmod tempor incididun</p>
              </div>  
              </div>
              <div class="mt-2">
                <p>Image from <Strong>Freepik</Strong></p>
              </div>
              <div class="pt-3">
                <button class="btn btn-primary px-4 border-0 rounded-0">Book Now</button>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 " id="sixth_section_2ndcol_lg">
              <div class="sixth_section_2ndcol_lg_2ndimg">
              <img class="img-fluid" src="src/assets/phone_call.png" style="width: 80px; height: 80px;"/>
            </div>
            <div>
              <img class="img-fluid mt-5" src="https://images01.nicepagecdn.com/a1389d7bc73adea1e1c1fb7e/8f93fb525fca5a7d86a20ba0/black-white-exterior-building.jpg" style="width: 550px; height: 350px;"/>
            </div>
          </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 " id="sixth_section_2ndcol_lg_2nd">
              <div class="sixth_section_2ndcol_lg_2ndimg_ig">
              <img class="img-fluid" src="src/assets/phone_call.png" style="width: 80px; height: 80px;"/>
            </div>
            <div class="image_section_6_second_row">
              <img class="img-fluid mt-3 " src="https://images01.nicepagecdn.com/a1389d7bc73adea1e1c1fb7e/fd44305e8d7e5cb4adf5f7cd/low-angle-shot-creative-modern-building-with-outstanding-architectural-twists.jpg" style="width: 550px; height: 350px;"/>
            </div>
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 " id="sixth_section_2ndrow_para_h5">
            <div>
              <div class="sixth_section_2ndrow_para_p">
                <p>Article evident arrived express highest men did boy. Mistress sensible entirely am so. Quick can manor smart money hopes worth too. Comfort produce husband boy her had hearing.</p>
              </div>
              <div class="sixth_section_2ndrow_para_h5">
                <h5>Oh feel if up to till like. He an thing rapid these after going drawn or. Timed she his law the spoil round defer. In surprise concerns informed betrayed he learning is ye.</h5>
              </div>
            </div>
          </div>
         </div>
        
      </div>
    </section>


          <!-- Seven Section -->
      <section class="section_7 mt-5 pb-5">
        <div class="container pt-5 pb-5">
          <div id="row_wise" class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 py-5 pb-5 mt-5" id="row_wise_1st_div">
               <div>
                 <h1>
                  Ready to get started?
                 </h1>
               </div>
               <div class="section7_1strow_1stcol">
                <p class="pt-4" >Sample text. Click to select the text box. Click again or double click to start editing the text. Excepteur sint occaecat cupidatat  non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
               </div>
               <div>
                <button class="btn btn-light pt-2 mt-3 px-4 border-none" >Learn More</button>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pt-5 mt-5 ">
              <div  class="row col-lg-6 col-md-6 mt-5" id="section7_row" >
              <div class="section7_1div">
                <div class="section7_icon mt-2" >
                  <img src="src/assets/Screenshot.png"/>
                </div>
                <div class="h5_p mx-4 mt-3 " id="section7_1strow_2ndcol_h5_p">
                  <h5>Sample Headline</h5>
                  <p class="pt-2" >Sample text. Click to select the text box. Click again or double click to start editing the text.</p>
                </div>
                </div>
              
              <div class="section7_1div pt-4">
                <div class="section7_icon mt-2" >
                  <img src="src/assets/Screenshot2.png"/>
                </div>
                <div class="h5_p mx-4 mt-3 " id="section7_1strow_2ndcol_h5_p">
                  <h5>Sample Headline</h5>
                  <p class="pt-2" >Sample text. Click to select the text box. Click again or double click to start editing the text.</p>
                </div>
              </div>
              <div class="section7_1div pt-4 pb-4">
                <div class="section7_icon mt-2" >
                  <img src="src/assets/Screenshot3.png"/>
                </div>
                <div class="h5_p mx-4 mt-3 mb-5 pb-5" id="section7_1strow_2ndcol_h5_p">
                  <h5>Sample Headline</h5>
                  <p class="pt-2" >Sample text. Click to select the text box. Click again or double click to start editing the text.</p>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </section>



      <!-- Eight Section -->
      <section class="section_8 pb-5">
        <div>
          <div class="card justify-content-center pt-4" >
            <div class=" top_the_image">
              <div class=" top_the_image_2div">
                <img src="src/assets/mimi.jpg" style="width: 180px;height: 180px;" />
              </div>
              <div>
                <p>
                  Duis aute irure dolor in reprehenderit in voluptate velit<br>  esse cillum dolore eu fugiat nulla pariatur. Excepteur sint <br> occaecat cupidatat non proident.
                </p>
              </div>
              <div class="pt-3">
                <img src="src/assets/quotes.png" style="width: 26%;height: 26%;" />
              </div>
            </div>
          </div>
        </div>
      </section>

</template>



   <!--   CSS Styles -->
<style scoped>
@media (min-width: 768px) {
  :root {
    font-size: calc(1rem + ((1vw - 7.68px) * 0.6944));
    min-height: 0vw;
  }
}
@media (min-width: 987px) {
  
}
@media (max-width: 700px){

  .first_section{
    max-height: 300px !important;
    min-height: 600px !important;
  }
  .first_section .paragraph{
    padding: 3% !important;
  }
   .first_section .paragraph div{
    padding: 0%;
    margin-top: 80px;
   }
   .paragraph div h2{
    font-size: xx-large;
    line-height: normal;
    margin-top: 25px;
   }
   .paragraph button{
    margin-bottom: 20px;
   }













  #sixth_section_1stcol_lg{
    text-align: center;
  }
  .section7_1strow_1stcol p{
    padding: 0 !important;
  }
  .section7_1div{
    display: flow-root !important;
    padding: 0 !important;
  }
  #row_wise{
    margin: 0px !important;
    padding: 0px !important;
  }
  #row_wise_1st_div{
    text-align: center !important;
    padding: 0 25px !important;
  }
}
@media (max-width: 976px){
#row_wise_1st_div[data-v-b4e148ca] {
    text-align: center !important;
    padding: 0 25px !important;
    align-self: center;
}
.section_5 .row{
  padding:1rem !important;
}
}

div#img_section_6 {
    display: flex;
    justify-content: end;
}
div#sixth_section_2ndcol_lg_2nd {
    display: flex;
    position: relative;
    justify-content: end;
}
.sixth_section_icon_img_div div {
    display: flex;
}
.sixth_section_icon_img_div p{
    margin-left: 12px;
}
div#sixth_section_row {
    display: flex;
    justify-content: end;
}
.sixth_section_1stcol_lg_h5 h5 {
    font-size: 24px;
    font-weight: normal;
}
div#sixth_section_1stcol_lg {
    align-self: center;
}
.sixth_section_2ndcol_lg_2ndimg {
    background: #2590f4;
    padding: 18px;
    display: flow;
    position: absolute;
    border-radius: 50%;
    margin: 9.5rem -3.4rem;
}
.sixth_section_2ndcol_lg_2ndimg_ig {
    background: #2590f4;
    padding: 18px;
    display: flow;
    position: absolute;
    border-radius: 50%;
    margin: 123px -50px 0px 0px;
}
.sixth_section_2ndcol_lg_2ndimg_2ndrow {
    display: flex;
    position: absolute;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: flex-end;
}
.sixth_section_2ndrow_para_p p {
    font-size: 21px;
    font-weight: 400;
    color: #5f5f5f;
}
.sixth_section_2ndrow_para_h5 h5{
  font-size: 21px;
  padding-right: 3rem;
}
div#sixth_section_2ndrow_para_h5 {
    align-self: center;
}
div#sixth_section_2ndrow_para_h5{
    padding-left: 3.5rem;
    padding-top: 38px;
}



#slide1{
  animation: 3s slide-right;
}
@keyframes slide-right {
  from {
    margin-left: -100%;
  }
  to {
    margin-left: 0%;
  }
}

img#row-wise1_image {
    margin-left: 8rem;
}


button.btn.btn-light.pt-2.mt-3.px-4.border-none {
    border-radius: initial;
}
.top_the_image_2div img {
    border-radius: inherit;
}
.top_the_image p {
    font-size: larger;
    margin-top: 1.5rem;
}

.top_the_image_2div {
    margin-top: -9rem;
    border-radius: 50%;
}
.top_the_image_2div img{
  box-shadow: 5px 5px 20px 0 rgba(0,0,0,0.15);
}
section.section_8 {
    display: flex;
    justify-content: center;
    padding: 0 27px;
}
.card.justify-content-center {
    padding: 4rem 5rem 2rem 5rem !important;
    margin-top: -7.3rem;
    text-align: center;
    border-radius: initial;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.col-lg-6.col-md-6.col-sm-12.col-xs-12.py-5.pb-5.mt-5 {
    display: flow-root;
  font-family: Montserrat, sans-serif !important;
}

.col-lg-6.col-md-6.col-sm-12.col-xs-12.py-5.pb-5.mt-5 h1{
  margin-top: 15%;
  color: white;
  font-weight: 700;
  font-family: Montserrat, sans-serif !important;
}
.section7_1strow_1stcol p{
  color:white;
  font-size: initial;
  font-weight: 200 !important;
  font-family: Montserrat, sans-serif !important;
  padding: 0 123px 0 0px;

}
.col-lg-6.col-md-6.col-sm-12.col-xs-12.pt-5.mt-5 {
    display: contents;
    position: absolute;
}
h5.section6_para.mt-2 {
    text-align: left;
    margin-left:4rem !important;
}
.withrightclick {
    display: flow;
    position: relative;
    margin-left: 9rem;
}
.col-lg-6.col-md-6.col-sm-6.col-xs-12 {
    display: flow-root;
    position: relative;
    text-align: end;

}


.section_7{
  background-color: #2590f4;
  min-height: 800px;
}
.col-lg-6.col-md-6.col-sm-12.col-xs-12.pt-4 {
    display: flow-root;
    text-align: center;
    align-self: center;
}
.h5_p.mx-4.mt-3 {
    color: white;
}
.h5_p.mx-4.mt-3 h5 {
    font-size: x-large;
    font-weight: inherit;
  font-family: Montserrat, sans-serif !important;
}
.h5_p.mx-4.mt-3 p{
  font-weight: initial;
  font-size: larger;
}
.section7_1div {
    display: flex;
    justify-content: center;
}
.heading_h {
    margin-left: 5rem !important;
}
body{
  font-family: "Roboto", "Arial","sans-serif";
}
.first_section{
  background-image: linear-gradient(0deg, rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url("https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-photo-1471751.png");
  background-position: 50% 50%;
  min-height: 740px;
  display: flex-root;
  background-size: cover;
  text-align: -webkit-center;
}
.paragraph {
  width: fit-content;
  text-align: center;
  display: flex;
  justify-content: center;
}

.paragraph div{
  border:13px solid #2590f4;
  padding: 40px 60px 40px 60px;
  margin-top: 110px;
  background-color: #e9e9e955;
  
}
.paragraph h2{
  font-weight: 700;
  font-family: Montserrat, sans-serif !important;
  font-size: 3.3rem;
  color: white;
  line-height: 3.9rem;
}
.paragraph p{
  color: white;
  font-family: Montserrat, sans-serif !important;
  font-size: 1.125rem;
  margin-top: 5px;
}
button a{  
    color: white;
    padding: 8px 15px 8px 15px;
}

/*  Hello Section */
.hello_header h2{
  font-family: Montserrat,sans-serif;
   text-align: center;
   font-size: 2.25rem;
   margin-top: 3rem;
   font-weight: 700;
   line-height: 2.6rem;
   margin-bottom: 3rem;

}
.col-lg-4 #right_click{
  background-color: #2590f4;
  border-radius: 20px ;
  width: 36px;
  height: 36px;
  padding: 8px;
}
.col-lg-4 p{
  margin-top: 15px;
}
#row_wise{
  margin-left: 40px;
  margin-right: 40px;
  padding-left: var(--bs-gutter-x, 5.75rem);
}
.row .b{
  margin-top: 5rem;
}
.btn .btn-primary .mt-5{
  padding: 5px 2px 5px 2px;
}


.images_section{
  background: #f2f2f2;
}

#hello_3{
  height: 352px;
  overflow: hidden;
}

#hello_3 img{
  object-fit: cover;
  transition: transform .5s ease;
}
#hello_3:hover img {
  transform: scale(1.1);
  box-sizing: border-box;
}
#profiles{
  display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    align-content: stretch;
    justify-content: space-evenly;
    align-items: center;
}

#profiles img{
   border-radius: 140px;
   padding: 30px;
   border: 9px solid #2590f4;
}
#profiles h5{
  font-size: 25px;
  font-family: Montserrat,sans-serif;
  color: inherit;
  font-weight: 300 !important;
}
#profiles h6{
  font-weight: 700;
  color: #2590f4;
  line-height: 1%;

}
#profiles a{ font-weight: 300;
    font-style: normal;
    margin: 23px 0 0;
    font-size: larger;
}
button.btn.btn-primary.mb-5.px-5.py-2 {
    font-size: larger;
}
.icons{
  background-color: #2590f4;
  border-radius: 1px;
}
.icons i{
    padding: 2px 10px 2px 10px;
    display: inline-flex;
    font-size: medium;
    font-size: x-large;
}
.para{
  text-align: center;
}

/* Section 5 */
.section_5{
  background-color: #f2f2f2;
  border: none;
}
.col-lg-5.col-md-5.col-sm-12.col-xs-12.card.pt-4.border-0 {
    display: flex;
    font-family: Montserrat, sans-serif !important;
    align-items: center;
}
.row.pt-5.pb-4{
    display: flex;
    justify-content: center;
}
.section_increment {
  height: 130px;
  width: 130px;
  background-color: #2590f4;
  border-radius: 50%;
}
.section_increment_p p{
  font-size: 18px;
  font-weight: normal;
  line-height: 1.5rem;
  text-align: center;
  color: #999999;
  font-family: Montserrat, sans-serif !important;
}
.section_increment span{
  color: white;
  font-weight: 700;
  font-size: 30px;
  display: flow-root;
  text-align: center;
}
.col-lg-6.col-md-6.col-sm-6.col-xs-12 {
    display: flow-root;
    align-self: center;
    text-align: center;
}

.icon12{
  width: 18%;
  height:18%;
  background-color: #2590f4;
  border-radius: 50%;
  margin-right: 15% !important;
}
.icon13{
  width: 18%;
  height: 18%;
  background-color: #2590f4;
  border-radius: 50%;
  padding: 12px;
}
.icon_div_logo_1 {
    display: flex;
    position: absolute;
    justify-content: flex-end;
    padding: 5%;
}
.icon_div_logo {
    display: flex;
    position: absolute;
    margin-top: 7rem;
    margin-left: -22px;
}
.col-lg-6.col-md-6.col-sm-12.col-xs-12 {
  display: flex;
  justify-content: center;
  font-family: Montserrat, sans-serif !important;
  align-items: center;
}
.blur_paragraph_h4.px-3 h5 {
  display: flex !important;
  font-family: Montserrat, sans-serif !important;
  font-size: initial;
  font-weight: 600;
}
h6.blur_paragraph.pb-3 {
    line-height: inherit;
    font-size: 16px;
    margin-left: 4rem;
}
.blur_paragraph_h4 h5{
    line-height: inherit;
    font-size: 18px;
    margin-left: 4rem;
}
.row.mt-5.px-4 {
    display: flex;
    justify-content: center;
    margin-left: 1.8rem;
}
h5.blur_paragraph {
    font-weight: 300 !important;
    font-size: initial;   
  font-family: Montserrat, sans-serif !important;
  text-align: start;
}
img.div_image {
    margin-right: 2rem;
}
h5.section6_para.mt-1 {
    display: flex;
    font-size: medium;
}
.col-lg-6.col-md-6.col-sm-6.col-xs-12 h5{
  font-weight: 200 !important ;
  font-family: Montserrat, sans-serif !important;
}
.img_para{
  display: flex;
}
.section6_para{
  font-weight: 200 !important ;
  font-family: Montserrat, sans-serif !important;
}
.section6_para a{
  color: #2590f4 !important;
}

button.btn.btn-primary.mb-5.mt-3.border-none[data-v-b4e148ca] {
    border-radius: 0;
    display: flex;
    margin-left: 7rem !important;
}

</style>