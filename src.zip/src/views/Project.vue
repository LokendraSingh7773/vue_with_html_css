<!-- eslint-disable vue/multi-word-component-names -->
<template>
    <section class="first_section">
        <div>
        <div class="paragraph">
          <div class="p-5" >
            <h2 class="pb-4 pt-5" >
                Product
            </h2>
            <p>Amet luctus venenatis lectus magna fringilla urna porttitor rhoncus<br> dolor. 
               A lacus vestibulum sed arcu non. Dolor magna eget est lorem <br>ipsum dolor sit amet consectetur.
            </p>
            <button class="btn btn-primary mt-4 mb-5 rounded-0"><a>Read more</a> </button>
          </div>
        </div>
    </div>
      </section>

      <!-- Second Section -->
      <section class="second_section py-4" >
        <div class="container px-2" id="second_sec_container">
            <div class="row p-3 mt-5" id="second_sec_row">
                <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 p-4" id="second_sec_oneside_col_lg">
                    <div class="second_sec_oneside_col_lg_h1">
                        <h1>Turn your ideas to live web experiences</h1>
                    </div>
                    <div class="second_sec_oneside_col_lg_h6 mt-2">
                        <h6>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident</h6>
                    </div>
                    <div class="second_sec_oneside_col_lg_p_a mt-3 ">
                        <p>Images from <Strong>Freepik</Strong></p>
                    </div>
                    <div class="second_sec_oneside_col_lg_btn ">
                        <button class="btn btn-primary border-0 rounded-0 mt-2 px-4 py-2">Read More</button>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12"  id="second_sec_secondside_col_lg">
                  <div class="second_sec_secondside_col_lg_second_div">
                  </div>
                </div>
            </div>
        </div>
        </section>

        <!-- third Section -->
        <section class="third_section pt-5 pb-5 mb-5">
            <div class="third_section_first_h1">
                <h1>Our Projects</h1>
            </div>
            <div class=" third_section_first_h6 pt-2 pb-2 ">
                <h6>
                    Sample text. Click to select the text box. Click again or <br> double click to start editing the text.
                </h6>
            </div>
            <div class="container "  id="third_section_container">
                <div class="row pt-5 px-5 mx-2" id="third_section_row">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 gap-sm-5 " id="third_section_all_images">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-francisco-valerio-trujillo-1824392.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-david-underland-3277468.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-john-lee-6434779.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-john-lee-6766628.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-matej-776336.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-mitchell-luo-3694708.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-olga-lioncat-7245550.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-sevenstorm-juhaszimrus-425160.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div>
                            <img class="img-fluid" src="https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-todd-trapani-2276927.jpg" style="width: 380px; height: 350px;"/>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Fourth Section -->
        <section class="fourth_section">
            <div class="container pb-5" id="fourth_section_container">
                <div class="row" id="fourth_section_row">
                    <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12 lg" id="fourth_section_row1st">
                        <div>
                            
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-4" id="second_sec_oneside_col_lg">
                    <div class="second_sec_oneside_col_lg_h1">
                        <h1>Turn your ideas to live web experiences</h1>
                    </div>
                    <div class="second_sec_oneside_col_lg_h6 mt-2">
                        <h6>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident</h6>
                    </div>
                    <div class="second_sec_oneside_col_lg_p_a mt-3 ">
                        <p>Images from <Strong>Freepik</Strong></p>
                    </div>
                    <div class="second_sec_oneside_col_lg_btn ">
                        <button class="btn btn-primary border-0 rounded-0 mt-2 px-4 py-2">Read More</button>
                    </div>
                </div>
                </div>
            </div>
        </section>
</template>

<style scoped>
/* Media Query */
@media (max-width: 576px){
.col-sm-12 {
    flex: 0 0 auto;
    width: 100%;
    text-align: center;
}
}



/* Fourth Section */
#fourth_section_row1st{
    background-image: url(https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-photo-3851285.jpeg);
    display: flex;
    position: relative;
    background-size: cover;
    background-position: 50% 50%;
    min-height: 543px;
    min-width: 00px;
}

div#fourth_section_row {
    justify-content: end;
}
div#fourth_section_container[data-v-71bdac12] {
    display: flex;
    position: relative;
    margin: auto;
}

/* Third Section */
.third_section{
    background-color: #f2f2f2;
    justify-content: center;
    text-align: center;
}
div#third_section_row img {
    margin-bottom: 22px;
}
div#third_section_row img :hover {
    -webkit-filter: blur(4px);
    filter: blur(4px);
}
.third_section_first_h1 h1 {
    font-weight: 700;
    font-size: 3rem;
}
.third_section_first_h6 h6 {
    font-size: 20px;
    font-weight: normal;
}


/* Second_section */
#second_sec_secondside_col_lg{
    background-image: url(https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-photo-733500copy.jpg);
    display: flex;
    position: relative;
    background-size: cover;
    background-position: 50% 50%;
    min-height: 543px;
    background-position-y: top;
}
div#second_sec_oneside_col_lg {
    display: flow;
    position: relative;
    align-self: center;
}
.second_sec_oneside_col_lg_h1 h1 {
    font-size: 3.2rem;
    font-weight: bold;
}
.second_sec_oneside_col_lg_h1 {
    padding: 0px 5px 5px 0px;
}
.second_sec_oneside_col_lg_h6 h6 {
    font-size: 18px;
    font-weight: normal;
    line-height: 2.3rem;
}
.second_sec_oneside_col_lg_p_a {
    margin-left: 10px;
    font-size: x-large;
}
div#second_sec_row {
    justify-content: center;
}


/* First Section */
.first_section{
  background-image: linear-gradient(0deg, rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url("src/assets/about_background.jpeg");
  background-position: 50% 50%;
  background-size: contain;
  min-height: 670px;
  background-size: cover;
  display: flex-root;
  text-align: -webkit-center;
}
.paragraph {
  width: fit-content;
  text-align: center;
  display: flex;
}
.paragraph div{
  border:15px solid #2590f4;
  padding: 40px 60px 40px 60px;
  margin-top: 80px;
  background-color: #f6f6f63d;
  
}
.paragraph h2{
  font-weight: 700;
  font-family: sans-serif !important;
  font-size: 3.3rem;
  color: white;
  line-height: 3.9rem;
}
.paragraph p{
  color: white;
  font-family: Montserrat, sans-serif !important;
  font-size: 1.150rem;
  margin-top: 5px;
}
button a{  
    color: white;
    padding: 8px 15px 8px 15px;
}
button.btn.btn-primary.mt-4.mb-5.rounded-0 {
    padding: 10px;
}
</style>