<!-- eslint-disable vue/multi-word-component-names -->
<template>

    <!-- First section -->
     <section class="first_section">
        <div>
        <div class="paragraph">
          <div class="p-5" >
            <h2 class="pb-4 pt-5" >
                Product
            </h2>
            <p>Amet luctus venenatis lectus magna fringilla urna porttitor rhoncus<br> dolor. 
               A lacus vestibulum sed arcu non. Dolor magna eget est lorem <br>ipsum dolor sit amet consectetur.
            </p>
            <button class="btn btn-primary mt-4 mb-5 rounded-0"><a>Read more</a> </button>
          </div>
        </div>
    </div>
    </section>

        <section class="second_section pt-5">
            <div class="mt-4 pb-5">
                <div class="second_section_heading_h1">
                    <h1>Meet Our Leaders</h1>
                </div >
                <div class="second_section_heading_p">
                    <p>Images by <strong>Freepik</strong></p>
                </div>
            </div>
        </section>

        <!-- third section -->
    <section class="third_section pb-5">
            <div class="container " id="third_section_container">
                <div class="row " id="third_section_row">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 pb-4" id="third_section_container_row1st_col-lg">
                        <div class="card px-4 mx-4 pt-4 pb-4 border-0 rounded-0" id="third_section_container_row1st_card">
                            <div class="pb-4">
                                <img class="img-fluid" src="https://images01.nicepagecdn.com/c461c07a441a5d220e8feb1a/47d488474b1750ad8f9a684f/fggf.jpg"/>
                            </div>
                            <div class="Paragraph_section_third  py-4">   
                                <div class="">
                                    <h5>Bob Greenfield</h5>
                                </div>
                                <div>
                                    <p><strong>Senior Partner</strong></p>
                                </div>
                            <div>
                                <div class="third_section_icon">
                                    <i class="fi fi-brands-instagram"></i>
                                    <i class="fi fi-brands-facebook"></i>
                                    <i class="fi fi-brands-twitter"></i>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 pb-4" id="third_section_container_row1st_col-lg">
                        <div class="card px-4 mx-4 pt-4 pb-4 border-0 rounded-0" id="third_section_container_row1st_card">
                            <div class="pb-4">
                                <img class="img-fluid" src="https://images01.nicepagecdn.com/c461c07a441a5d220e8feb1a/23f2b6ec8f435911852884f1/2.jpg"/>
                            </div>
                            <div class="Paragraph_section_third  py-4">   
                                <div class="">
                                    <h5>Mary Brown</h5>
                                </div>
                                <div>
                                    <p><strong>Senior Partner</strong></p>
                                </div>
                            <div>
                                <div class="third_section_icon">
                                    <i class="fi fi-brands-instagram"></i>
                                    <i class="fi fi-brands-facebook"></i>
                                    <i class="fi fi-brands-twitter"></i>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 pb-4" id="third_section_container_row1st_col-lg">
                        <div class="card px-4 mx-4 pt-4 pb-4 border-0 rounded-0" id="third_section_container_row1st_card">
                            <div class="pb-4">
                                <img class="img-fluid" src="https://images01.nicepagecdn.com/c461c07a441a5d220e8feb1a/dee2a7ea9eea577cab16110a/fff.jpg"/>
                            </div>
                            <div class="Paragraph_section_third  py-4">   
                                <div class="">
                                    <h5>Ann Richmond</h5>
                                </div>
                                <div>
                                    <p><strong>Creative Leader</strong></p>
                                </div>
                            <div>
                                <div class="third_section_icon">
                                    <i class="fi fi-brands-instagram"></i>
                                    <i class="fi fi-brands-facebook"></i>
                                    <i class="fi fi-brands-twitter"></i>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 pb-4" id="third_section_container_row1st_col-lg">
                        <div class="card px-4 mx-4 pt-4 pb-4 border-0 rounded-0" id="third_section_container_row1st_card">
                            <div class="pb-4">
                                <img class="img-fluid" src="https://assets.nicepagecdn.com/d2cc3eaa/144337/images/85606321-2e4c-c7d6-cf63-40a071b1a74f.jpg"/>
                            </div>
                            <div class="Paragraph_section_third  py-4">   
                                <div class="">
                                    <h5>Roxie Swanson</h5>
                                </div>
                                <div>
                                    <p><strong>Managing Director</strong></p>
                                </div>
                            <div>
                                <div class="third_section_icon">
                                    <i class="fi fi-brands-instagram"></i>
                                    <i class="fi fi-brands-facebook"></i>
                                    <i class="fi fi-brands-twitter"></i>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 pb-4" id="third_section_container_row1st_col-lg">
                        <div class="card px-4 mx-4 pt-4 pb-4 border-0 rounded-0" id="third_section_container_row1st_card">
                            <div class="pb-4">
                                <img class="img-fluid" src="https://assets.nicepagecdn.com/d2cc3eaa/144337/images/1bf3445c-9167-a2ab-1d99-7d1e10b9ca40.jpg"/>
                            </div>
                            <div class="Paragraph_section_third  py-4">   
                                <div class="">
                                    <h5>Mattie Smith</h5>
                                </div>
                                <div>
                                    <p><strong>Global Leader</strong></p>
                                </div>
                            <div>
                                <div class="third_section_icon">
                                    <i class="fi fi-brands-instagram"></i>
                                    <i class="fi fi-brands-facebook"></i>
                                    <i class="fi fi-brands-twitter"></i>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 pb-4" id="third_section_container_row1st_col-lg">
                        <div class="card px-4 mx-4 pt-4 pb-4 border-0 rounded-0" id="third_section_container_row1st_card">
                            <div class="pb-4">
                                <img class="img-fluid" src="https://assets.nicepagecdn.com/d2cc3eaa/144337/images/bfc247f2-f373-5cb6-b168-2c091f869ba9.jpg"/>
                            </div>
                            <div class="Paragraph_section_third  py-4">   
                                <div class="">
                                    <h5>Betty Nilson</h5>
                                </div>
                                <div>
                                    <p><strong>Creative Leader</strong></p>
                                </div>
                            <div>
                                <div class="third_section_icon">
                                    <i class="fi fi-brands-instagram"></i>
                                    <i class="fi fi-brands-facebook"></i>
                                    <i class="fi fi-brands-twitter"></i>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<style scoped>
 /* Third section */
 div#third_section_container_row1st_col-lg {
    text-align: center;
}
.Paragraph_section_third {
    background: #f2f2f2;
}
.Paragraph_section_third h5{
    font-weight: normal;
    font-size: 23px;
}
.third_section_icon i {
    padding: 0 10px;
    font-size: 27px;
    color: #2590f4;
}
#third_section_container_row1st_card{
    /* margin-top: -12rem; */
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
div#third_section_container {
    margin-top: -11rem;
    padding-bottom: 5px;
}

  /* Second Section */
section.second_section.pt-5 {
    justify-content: center;
    text-align: center;
    background-color: #2590f4;
    color: white;   
    padding-bottom: 15rem;
}
.second_section_heading_h1 h1 {
    font-size: 50px;
    font-weight: bold;
}




.first_section{
  background-image: linear-gradient(0deg, rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url("https://assets.nicepagecdn.com/11a8ddce/3667110/images/pexels-sevenstorm-juhaszimrus-425160.jpg");
  background-position: 50% 50%;
  background-size: contain;
  min-height: 670px;
  background-size: cover;
  display: flex-root;
  text-align: -webkit-center;
}
.paragraph {
  width: fit-content;
  text-align: center;
  display: flex;
}
.paragraph div{
  border:15px solid #2590f4;
  padding: 40px 60px 40px 60px;
  margin-top: 80px;
  background-color: #f6f6f63d;
  
}
.paragraph h2{
  font-weight: 700;
  font-family: sans-serif !important;
  font-size: 3.3rem;
  color: white;
  line-height: 3.9rem;
}
.paragraph p{
  color: white;
  font-family: Montserrat, sans-serif !important;
  font-size: 1.150rem;
  margin-top: 5px;
}
button a{  
    color: white;
    padding: 8px 15px 8px 15px;
}
button.btn.btn-primary.mt-4.mb-5.rounded-0 {
    padding: 10px;
}
</style>